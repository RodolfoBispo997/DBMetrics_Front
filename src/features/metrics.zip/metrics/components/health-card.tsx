import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DatabaseHealth } from "../types/database-metrics";
import { getHealthStatus } from "../utils/health";

type Props = {
  health: DatabaseHealth;
};

export function HealthCard({ health }: Props) {
  const status = getHealthStatus(health.status);

  const Icon = status.icon;

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle className="text-sm uppercase tracking-wider text-muted-foreground">
          Database Health
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-6">
        <div className="flex items-center gap-3">
          <Icon className={`h-7 w-7 ${status.color}`} />

          <div>
            <p className="text-2xl font-semibold">{status.title}</p>

            <p className="text-sm text-muted-foreground">
              {status.description}
            </p>
          </div>
        </div>

        <div className="border-t pt-4">
          <p className="text-xs uppercase tracking-wide text-muted-foreground">
            Last check
          </p>

          <p className="mt-1 text-sm">
            {new Date(health.checkedAt).toLocaleString()}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
