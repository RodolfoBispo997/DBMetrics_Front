import { useMutation } from "@tanstack/react-query";

import { databaseConnectionsService } from "../services/database-connections.service";

export function useTestDatabaseConnection() {
  return useMutation({
    mutationFn: databaseConnectionsService.test,

    onSuccess(data) {
      // toast de sucesso
    },

    onError(error) {
      // toast de erro
    },
  });
}
