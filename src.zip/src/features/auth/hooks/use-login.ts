"use client";

import { useMutation } from "@tanstack/react-query";

import { login } from "@/features/auth/services/auth.service";

export function useLogin() {
  return useMutation({
    mutationFn: login,
  });
}
